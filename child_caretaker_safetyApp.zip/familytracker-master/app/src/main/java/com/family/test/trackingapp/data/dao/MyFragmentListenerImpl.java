package com.family.test.trackingapp.data.dao;

public interface MyFragmentListenerImpl {
        void onFabButtonClicked();
    }
